# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the ESLint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and [`typescript-eslint`](https://typescript-eslint.io) in your project.
# Aethel Music Frontend

Frontend existente en React y JavaScript (Vite). La capa API está en `src/services/api.js` y usa `VITE_API_URL`.

## Ejecutar localmente

1. Inicia el backend desde `C:/Users/PC/Downloads/BackEnd` con `python -m uvicorn main:app --reload`.
2. Copia `.env.example` como `.env` y ajusta `VITE_API_URL` si el backend no escucha en `http://127.0.0.1:8000`.
3. Desde esta carpeta ejecuta `npm install` solo si aún no están instaladas las dependencias y luego `npm run dev`.
4. Abre la URL local que muestra Vite. El backend debe permitir el origen del frontend en `CORS_ORIGINS`.

## Conexiones implementadas

- Registro e inicio de sesión JWT; el token Bearer se adjunta automáticamente a las peticiones protegidas.
- Perfil y foto de perfil, biblioteca de pistas, importación de audio, playlists mostradas en la sección de álbumes y asociación de pistas, favoritos, ajustes de tema/escala, importación de efectos y asignación a pads.
- Los errores HTTP y de conexión se convierten en mensajes para la interfaz.

## Pendiente del backend para completar los flujos

- No hay endpoint para crear una grabación a partir del audio grabado en el navegador ni para guardar estado de la consola DJ. La grabación sigue descargándose localmente.
- El backend ofrece consulta/edición/eliminación de grabaciones, pero la interfaz actual no tiene una pantalla para gestionarlas.
- El backend devuelve rutas de archivos, pero `main.py` no expone `Storage` como contenido estático. Para reproducir pistas/efectos guardados, falta servir esos archivos o incluir una URL de descarga en las respuestas.
- Las imágenes/portadas de playlists no tienen operación de carga en el backend; se conserva la portada visual local.
- `VITE_API_URL` debe estar habilitado en CORS del backend para el origen real donde corra Vite.
- El frontend recibido está hecho con archivos `.jsx` (JavaScript), no TypeScript; se mantuvo su stack y navegación existentes.
