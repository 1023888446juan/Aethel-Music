import favoritasTexture from "../../assets/img/Albumes/Favoritas.png";
import favoritosIcon from "../../assets/img/reproductor_icons/favoritos.png";


// =========================================
// FAVORITOS
// =========================================

function Favoritos({ onOpen, onClose, onSelect, isOpen, songs = [], favoriteIds = [], count = 0 }) {
    const favoriteSongs = songs.filter((song) => favoriteIds.includes(song.id));

    return (

        <>

        <section className="album-section">

            <div className="section-title">

                <div>

                    <span className="section-label">
                        COLECCIÓN ESPECIAL
                    </span>

                    <h2>
                        FAVORITAS
                    </h2>

                </div>

            </div>


            <div className="favorite-card">


                {/* =================================
                    IMAGEN
                    ================================= */}

                <div
                    className="favorite-image"
                    style={{
                        backgroundImage:
                            `url(${favoritasTexture})`
                    }}
                >

                    <div className="favorite-overlay"></div>


        

                </div>


                {/* =================================
                    INFORMACIÓN
                    ================================= */}

                <div className="favorite-info">

                    <span className="card-type">
                        COLECCIÓN
                    </span>

                    <h3>
                        Mis favoritas
                    </h3>

                    <p>
                        Todas las canciones que has marcado
                        como favoritas.
                    </p>

                    <span className="song-count">
                        {count} canciones
                    </span>

                </div>


                {/* =================================
                    ABRIR
                    ================================= */}

                <button
                    type="button"
                    className="open-album-button"
                    onClick={onOpen}
                >

                    ABRIR

                </button>


            </div>

        </section>

            {isOpen && (
                <div className="config-album-overlay" role="dialog" aria-modal="true" aria-label="Canciones favoritas">
                    <div className="config-album-window">
                        <div className="config-album-header">
                            <div><span className="config-album-label">COLECCIÓN</span><h2>MIS FAVORITAS</h2></div>
                            <button type="button" className="config-album-close" onClick={onClose}>×</button>
                        </div>
                        <div className="config-album-body" style={{ display: "block", maxHeight: "55vh", overflowY: "auto" }}>
                            {favoriteSongs.length ? favoriteSongs.map((song) => (
                                <button key={song.id} type="button" className="song" onClick={() => { onSelect?.(song); onClose?.(); }}>
                                    <span className="song-info"><span className="song-title">{song.title}</span><span className="song-artist">{song.artist}</span></span>
                                </button>
                            )) : <p>Aún no has agregado canciones favoritas.</p>}
                        </div>
                    </div>
                </div>
            )}
        </>
    );

}


export default Favoritos;
