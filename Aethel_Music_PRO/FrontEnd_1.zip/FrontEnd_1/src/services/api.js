const API_URL = (import.meta.env.VITE_API_URL || "http://127.0.0.1:8000").replace(/\/$/, "");
const TOKEN_KEY = "aethel_access_token";
const USER_KEY = "usuario";

export function getToken() {
    return localStorage.getItem(TOKEN_KEY) || localStorage.getItem("token");
}

export function setSession(token, user) {
    if (token) {
        localStorage.setItem(TOKEN_KEY, token);
        localStorage.setItem("token", token);
    }
    if (user) localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("token");
    localStorage.removeItem(USER_KEY);
}

async function request(path, options = {}) {
    const headers = new Headers(options.headers || {});
    const token = getToken();
    if (token) headers.set("Authorization", `Bearer ${token}`);
    if (options.body && !(options.body instanceof FormData) && !headers.has("Content-Type")) {
        headers.set("Content-Type", "application/json");
    }
    let response;
    try {
        response = await fetch(`${API_URL}${path}`, { ...options, headers });
    } catch {
        throw new Error("No se pudo conectar con el servidor. Verifica la URL y que FastAPI esté ejecutándose.");
    }
    const text = await response.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (!response.ok) {
        const detail = data?.detail;
        const message = Array.isArray(detail)
            ? detail.map((item) => `${item.loc?.slice(-1)[0] || "Campo"}: ${item.msg}`).join(". ")
            : typeof detail === "string" ? detail : `Error del servidor (${response.status})`;
        if (response.status === 401) clearSession();
        throw new Error(message);
    }
    return data;
}

const json = (method, body) => ({ method, body: JSON.stringify(body) });
const query = (value) => encodeURIComponent(value);

export const api = {
    register: (payload) => request("/api/usuarios/registro", json("POST", payload)),
    login: async (correo, password) => {
        const result = await request("/api/auth/login", json("POST", { correo, password }));
        setSession(result.access_token, result.usuario);
        return result;
    },
    profile: () => request("/api/usuarios/perfil"),
    updateProfile: (payload) => request("/api/usuarios/perfil", json("PUT", payload)),
    uploadProfilePhoto: (file) => {
        const form = new FormData(); form.append("archivo", file);
        return request("/api/usuarios/perfil/foto", { method: "POST", body: form });
    },
    deleteProfilePhoto: () => request("/api/usuarios/perfil/foto", { method: "DELETE" }),
    tracks: () => request("/api/pistas/"),
    importTrack: (file) => {
        const form = new FormData(); form.append("archivo", file);
        return request("/api/pistas/importar", { method: "POST", body: form });
    },
    deleteTrack: (id) => request(`/api/pistas/${query(id)}`, { method: "DELETE" }),
    playlists: () => request("/api/playlists/"),
    createPlaylist: (nombre) => request("/api/playlists/", json("POST", { nombre })),
    updatePlaylist: (id, nombre) => request(`/api/playlists/${query(id)}`, json("PUT", { nombre })),
    deletePlaylist: (id) => request(`/api/playlists/${query(id)}`, { method: "DELETE" }),
    playlistTracks: (id) => request(`/api/playlists/${query(id)}/pistas`),
    addPlaylistTrack: (playlistId, trackId) => request(`/api/playlists/${query(playlistId)}/pistas`, json("POST", { fk_id_pista: trackId })),
    removePlaylistTrack: (playlistId, trackId) => request(`/api/playlists/${query(playlistId)}/pistas/${query(trackId)}`, { method: "DELETE" }),
    favorites: () => request("/api/favoritos/"),
    addFavorite: (trackId) => request("/api/favoritos/", json("POST", { fk_id_pista: trackId })),
    removeFavorite: (trackId) => request(`/api/favoritos/pista/${query(trackId)}`, { method: "DELETE" }),
    pads: () => request("/api/pads/"),
    effects: () => request("/api/efectos/"),
    importEffect: (file) => {
        const form = new FormData(); form.append("archivo", file);
        return request("/api/efectos/importar", { method: "POST", body: form });
    },
    assignPadEffect: (number, effectId) => request(`/api/pads/numero/${query(number)}/efecto/${query(effectId)}`, { method: "PUT" }),
    clearPadEffect: (number) => request(`/api/pads/numero/${query(number)}/efecto`, { method: "DELETE" }),
    recordings: () => request("/api/grabaciones/"),
    renameRecording: (id, titulo) => request(`/api/grabaciones/${query(id)}?titulo=${query(titulo)}`, { method: "PUT" }),
    deleteRecording: (id) => request(`/api/grabaciones/${query(id)}`, { method: "DELETE" }),
    configuration: () => request("/api/configuracion/"),
    saveConfiguration: (payload) => request("/api/configuracion/", json("PUT", payload)),
    resetConfiguration: () => request("/api/configuracion/restaurar", { method: "POST" })
};

export async function obtenerUsuarios() {
    return api.profile();
}

export function mediaUrl(path) {
    if (!path) return "";
    if (/^(https?:|blob:|data:)/i.test(path)) return path;
    return `${API_URL}/${String(path).replace(/^\/+/, "")}`;
}
