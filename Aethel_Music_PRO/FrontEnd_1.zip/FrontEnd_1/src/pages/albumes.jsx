/* =========================================================
   1. IMPORTS, ESTADO Y EFECTOS
   ========================================================= */

import { useEffect, useRef, useState } from "react";

import "../styles/interfaces_navbar/albumes.css";

import List from "../components/List";

import Favoritos from "../components/albumes/favoritos";
import ListaDeAlbums from "../components/albumes/listadeAlbums";
import CrearAlbum from "../components/albumes/crearAlbum";
import { api } from "../services/api";

import albumTexture from "../assets/img/Albumes/Album.png";

const STORAGE_KEYS = {
    colorMode: "aethel_color_mode",
    textSize: "aethel_text_size"
};

function Albumes() {
    const [colorMode, setColorMode] = useState(() => {
        const saved = localStorage.getItem(STORAGE_KEYS.colorMode);
        return saved === "light" || saved === "dark" ? saved : "dark";
    });

    const [textSize, setTextSize] = useState(() => {
        const saved = Number(localStorage.getItem(STORAGE_KEYS.textSize));
        return saved >= 80 && saved <= 130 ? saved : 100;
    });

    const [albums, setAlbums] = useState([]);

    const [mostrarCrearAlbum, setMostrarCrearAlbum] =
        useState(false);

    const [songs, setSongs] = useState([]);
    const [favoriteIds, setFavoriteIds] = useState([]);

    const [albumSeleccionado, setAlbumSeleccionado] =
        useState(null);

    const [mostrarFavoritos, setMostrarFavoritos] =
        useState(false);

    const fileInputRef = useRef(null);
    const contentRef = useRef(null);

    const textScale = textSize / 100;

    useEffect(() => {
        const syncPreferences = () => {
            const attrTheme = document.documentElement.getAttribute("data-theme");
            const savedTheme = localStorage.getItem(STORAGE_KEYS.colorMode);
            const nextTheme =
                attrTheme === "light" || attrTheme === "dark"
                    ? attrTheme
                    : savedTheme === "light" || savedTheme === "dark"
                        ? savedTheme
                        : "dark";

            const cssScale = Number(
                getComputedStyle(document.documentElement).getPropertyValue("--cfg-text-scale")
            );
            const savedText = Number(localStorage.getItem(STORAGE_KEYS.textSize));

            setColorMode(nextTheme);

            if (!Number.isNaN(cssScale) && cssScale > 0) {
                setTextSize(Math.round(cssScale * 100));
            } else if (savedText >= 80 && savedText <= 130) {
                setTextSize(savedText);
            }
        };

        syncPreferences();

        const observer = new MutationObserver(syncPreferences);
        observer.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ["data-theme", "style"]
        });

        window.addEventListener("storage", syncPreferences);

        return () => {
            observer.disconnect();
            window.removeEventListener("storage", syncPreferences);
        };
    }, []);

    useEffect(() => {
        api.favorites().then((items) => setFavoriteIds(items.map((item) => item.fk_id_pista))).catch(() => {});
    }, []);

    useEffect(() => {
        const obtenerAlbumes = async () => {
            try {
                const data = await api.playlists();

                const albumesFormateados = data.map(
                    (album) => ({
                        id: album.id_playlist,

                        name: album.nombre,

                        description:
                            "Playlist personal",

                        songs: 0,

                        texture: albumTexture
                    })
                );

                setAlbums(
                    albumesFormateados
                );
            } catch (error) {
                console.error(
                    "Error conectando con el backend:",
                    error
                );
            }
        };

        obtenerAlbumes();
    }, []);

    useEffect(() => {
        const obtenerCanciones = async () => {
            try {
                const data = await api.tracks();

                const cancionesFormateadas = data.map(
                    (pista) => ({
                        id: pista.id_pista,

                        title: pista.titulo,

                        artist:
                            pista.artista ||
                            "Artista desconocido",

                        genre: "Todas",

                        albumId:
                            null,

                        duration:
                            Number(pista.duracion),

                        format:
                            pista.formato,

                        path:
                            pista.ruta_archivo
                    })
                );

                setSongs(
                    cancionesFormateadas
                );
            } catch (error) {
                console.error(
                    "Error obteniendo canciones:",
                    error
                );
            }
        };

        obtenerCanciones();
    }, []);


    /* =========================================================
       2. HANDLERS
       ========================================================= */

    const handleSelectAlbum = (album) => {
        setAlbumSeleccionado(
            album
        );
    };

    const handleOpenFavorites = () => {
        setMostrarFavoritos(true);
    };

    const handleFavoritesContainerClick = (event) => {
        const openButton = event.target.closest(".open-album-button");
        if (openButton) {
            event.preventDefault();
            event.stopPropagation();
        }

        const favoriteCard = event.target.closest(".favorite-card");
        if (favoriteCard || contentRef.current?.contains(event.target)) {
            handleOpenFavorites();
        }
    };

    const handleUploadClick = () => {
        if (!albumSeleccionado) {
            alert(
                "Primero selecciona un álbum."
            );

            return;
        }

        fileInputRef.current?.click();
    };

    const handleFileChange = async (event) => {
        const archivo =
            event.target.files[0];

        if (!archivo) {
            return;
        }

        if (!albumSeleccionado) {
            alert(
                "Primero selecciona un álbum."
            );

            event.target.value = "";

            return;
        }

        try {
            const result = await api.importTrack(archivo);
            const data = result.pista;
            if (!data) throw new Error(result.mensaje || "El backend no importó la pista.");
            await api.addPlaylistTrack(albumSeleccionado.id, data.id_pista);
            setFavoriteIds((ids) => ids);

            alert(
                "Canción subida correctamente"
            );

            const nuevaCancion = {
                id:
                    data.id_pista,

                title:
                    data.titulo,

                artist:
                    data.artista ||
                    "Artista desconocido",

                genre:
                    "Todas",

                albumId:
                    albumSeleccionado.id,

                duration:
                    Number(data.duracion),

                format:
                    data.formato,

                path:
                    data.ruta_archivo
            };

            setSongs(
                (previousSongs) => [
                    ...previousSongs,
                    nuevaCancion
                ]
            );
        } catch (error) {
            console.error(
                "Error al subir la canción:",
                error
            );

            alert(error.message || "No se pudo conectar con el servidor");
        } finally {
            event.target.value = "";
        }
    };

    const handleCreateAlbum = async (
        newAlbum
    ) => {
        try {
            const data = await api.createPlaylist(newAlbum.titulo_album);

            const albumCreado = {
                id:
                    data.id_playlist,

                name:
                    data.nombre,

                description:
                    "Playlist personal",

                songs:
                    0,

                texture:
                    newAlbum.texture ||
                    albumTexture
            };

            setAlbums(
                (previousAlbums) => [
                    ...previousAlbums,
                    albumCreado
                ]
            );

            setMostrarCrearAlbum(
                false
            );
        } catch (error) {
            console.error(
                "Error creando álbum:",
                error
            );

            alert(
                error.message || "No se pudo conectar con el servidor"
            );
        }
    };

    const handleDeleteAlbum = async (
        albumId
    ) => {
        try {
            await api.deletePlaylist(albumId);

            setAlbums(
                (previousAlbums) =>
                    previousAlbums.filter(
                        (album) =>
                            album.id !== albumId
                    )
            );

            if (
                albumSeleccionado?.id ===
                albumId
            ) {
                setAlbumSeleccionado(
                    null
                );
            }
        } catch (error) {
            console.error(
                "Error eliminando álbum:",
                error
            );

            alert(error.message || "No se pudo conectar con el servidor");
        }
    };

    const handleUpdateAlbum = async (updatedAlbum) => {
        try {
            await api.updatePlaylist(updatedAlbum.id, updatedAlbum.name);
        setAlbums(
            (previousAlbums) =>
                previousAlbums.map(
                    (album) =>
                        album.id ===
                        updatedAlbum.id
                            ? {
                                ...album,
                                ...updatedAlbum
                            }
                            : album
                )
        );
        } catch (error) { alert(error.message); }
    };


    /* =========================================================
       3. RENDER PRINCIPAL
       ========================================================= */

    return (
        <div
            className="albumes-container"
            data-theme={colorMode}
            style={{ "--cfg-text-scale": textScale }}
        >

            {/* -----------------------------------------------------
                LISTA LATERAL
            ----------------------------------------------------- */}

            <List
                songs={songs}
            />


            {/* -----------------------------------------------------
                CONTENIDO PRINCIPAL
            ----------------------------------------------------- */}

            <main
                className="albumes-main"
                data-theme={colorMode}
                style={{ "--cfg-text-scale": textScale }}
            >

                <div className="albumes-background"></div>

                <div
                    ref={contentRef}
                    className="albumes-content"
                >

                    {/* -------------------------------------------------
                        HEADER
                    ------------------------------------------------- */}

                    <div className="albumes-header">

                        <div>

                            <span className="albumes-subtitle">
                                TU BIBLIOTECA
                            </span>

                            <h1>
                                ÁLBUMES
                            </h1>

                            <p>
                                Organiza tu música en tus propias playlists.
                            </p>

                        </div>

                        <div className="albumes-header-buttons">

                            <button
                                type="button"
                                className="create-album-button"
                                onClick={() =>
                                    setMostrarCrearAlbum(true)
                                }
                            >

                                <span className="create-icon">
                                    +
                                </span>

                                <span>
                                    CREAR PLAYLIST
                                </span>

                            </button>

                            <button
                                type="button"
                                className="upload-music-button"
                                onClick={
                                    handleUploadClick
                                }
                            >

                                <span className="upload-icon">
                                    ↑
                                </span>

                                <span>
                                    SUBIR MÚSICA
                                </span>

                            </button>

                            <input
                                ref={fileInputRef}
                                type="file"
                                accept=".mp3,.wav,.aiff,.m4a,.opus"
                                style={{
                                    display: "none"
                                }}
                                onChange={
                                    handleFileChange
                                }
                            />

                        </div>

                    </div>


                    {/* -------------------------------------------------
                        FAVORITAS
                    ------------------------------------------------- */}

                    <div
                        className="favorites-clickable-wrapper"
                        role="button"
                        tabIndex={0}
                        onClick={handleFavoritesContainerClick}
                        onKeyDown={(event) => {
                            if (event.key === "Enter" || event.key === " ") {
                                event.preventDefault();
                                handleOpenFavorites();
                            }
                        }}
                    >
                        <Favoritos
                            songs={songs}
                            favoriteIds={favoriteIds}
                            count={favoriteIds.length}
                            onOpen={handleOpenFavorites}
                            onSelect={handleOpenFavorites}
                            isOpen={mostrarFavoritos}
                            onClose={() => setMostrarFavoritos(false)}
                        />
                    </div>


                    {/* -------------------------------------------------
                        LISTA DE ÁLBUMES
                    ------------------------------------------------- */}

                    <ListaDeAlbums
                        albums={
                            albums
                        }
                        onCreate={() =>
                            setMostrarCrearAlbum(
                                true
                            )
                        }
                        onDelete={
                            handleDeleteAlbum
                        }
                        onUpdate={
                            handleUpdateAlbum
                        }
                        onSelectAlbum={
                            handleSelectAlbum
                        }
                    />

                </div>

            </main>


            {/* -----------------------------------------------------
                MODAL CREAR ÁLBUM
            ----------------------------------------------------- */}

            {mostrarCrearAlbum && (
                <CrearAlbum
                    onClose={() =>
                        setMostrarCrearAlbum(
                            false
                        )
                    }
                    onCreate={
                        handleCreateAlbum
                    }
                />
            )}

        </div>
    );
}

export default Albumes;
