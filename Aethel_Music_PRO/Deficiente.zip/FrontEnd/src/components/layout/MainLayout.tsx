import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import Header from "./Header";

function MainLayout() {
    return (
        <div className="main-layout">
            <Sidebar />

            <div className="main-layout__workspace">
                <Header />

                <main className="main-layout__content">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}

export default MainLayout;
