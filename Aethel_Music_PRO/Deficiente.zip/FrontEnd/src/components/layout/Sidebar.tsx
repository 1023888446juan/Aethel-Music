import { NavLink } from "react-router-dom";
import {
    Library,
    ListMusic,
    Heart,
    UserRound,
    Settings,
    AudioLines,
} from "lucide-react";

const navigationItems = [
    {
        label: "Biblioteca",
        path: "/biblioteca",
        icon: Library,
    },
    {
        label: "Playlists",
        path: "/playlists",
        icon: ListMusic,
    },
    {
        label: "Favoritos",
        path: "/favoritos",
        icon: Heart,
    },
    {
        label: "Efectos",
        path: "/efectos",
        icon: AudioLines,
    },
];

function Sidebar() {
    return (
        <aside className="sidebar">
            <div className="sidebar__brand">
                <div className="sidebar__brand-icon">
                    <AudioLines size={26} />
                </div>

                <div className="sidebar__brand-text">
                    <h1>Aethel</h1>
                    <span>Music</span>
                </div>
            </div>

            <nav className="sidebar__navigation">
                <span className="sidebar__section-title">
                    Biblioteca musical
                </span>

                {navigationItems.map((item) => {
                    const Icon = item.icon;

                    return (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) =>
                                `sidebar__link ${
                                    isActive ? "sidebar__link--active" : ""
                                }`
                            }
                        >
                            <Icon size={20} />
                            <span>{item.label}</span>
                        </NavLink>
                    );
                })}
            </nav>

            <div className="sidebar__bottom">
                <NavLink
                    to="/perfil"
                    className={({ isActive }) =>
                        `sidebar__link ${
                            isActive ? "sidebar__link--active" : ""
                        }`
                    }
                >
                    <UserRound size={20} />
                    <span>Perfil</span>
                </NavLink>

                <NavLink
                    to="/configuracion"
                    className={({ isActive }) =>
                        `sidebar__link ${
                            isActive ? "sidebar__link--active" : ""
                        }`
                    }
                >
                    <Settings size={20} />
                    <span>Configuración</span>
                </NavLink>
            </div>
        </aside>
    );
}

export default Sidebar;
