function Header() {
    return (
        <header className="main-header">
            <div className="main-header__content">
                {/* Elementos del encabezado definidos por la interfaz */}
            </div>
        </header>
    );
}

export default Header;
