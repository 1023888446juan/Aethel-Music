import { useRef, useState } from "react";
import libraryService from "../../services/libraryService";
import type { RespuestaImportacionMultiple } from "../../types/track";

interface MusicImportProps {
    onImportComplete: () => void;
}

function MusicImport({ onImportComplete }: MusicImportProps) {
    const inputRef = useRef<HTMLInputElement>(null);

    const [archivos, setArchivos] = useState<File[]>([]);
    const [cargando, setCargando] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [resultado, setResultado] =
        useState<RespuestaImportacionMultiple | null>(null);

    const seleccionarArchivos = (
        evento: React.ChangeEvent<HTMLInputElement>
    ) => {
        const seleccion = Array.from(evento.target.files ?? []);

        setArchivos(seleccion);
        setError(null);
        setResultado(null);
    };

    const importar = async () => {
        if (archivos.length === 0) {
            setError("Selecciona al menos un archivo de audio.");
            return;
        }

        setCargando(true);
        setError(null);
        setResultado(null);

        try {
            const respuesta = await libraryService.importarMultiples(archivos);

            setResultado(respuesta);
            setArchivos([]);

            if (inputRef.current) {
                inputRef.current.value = "";
            }

            onImportComplete();
        } catch (err: any) {
            setError(
                err?.response?.data?.detail ??
                "No fue posible importar los archivos."
            );
        } finally {
            setCargando(false);
        }
    };

    const cancelar = () => {
        setArchivos([]);
        setError(null);
        setResultado(null);

        if (inputRef.current) {
            inputRef.current.value = "";
        }
    };

    const formatoTamano = (bytes: number) => {
        if (bytes < 1024 * 1024) {
            return `${(bytes / 1024).toFixed(1)} KB`;
        }

        return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    };

    return (
        <section className="music-import">
            <div className="music-import__header">
                <h2>Importar música</h2>
                <p>Selecciona uno o varios archivos de audio.</p>
            </div>

            <input
                ref={inputRef}
                type="file"
                accept="audio/*"
                multiple
                onChange={seleccionarArchivos}
            />

            {archivos.length > 0 && (
                <div className="music-import__selection">
                    <p>
                        {archivos.length} archivo(s) seleccionado(s)
                    </p>

                    <ul>
                        {archivos.map((archivo, indice) => (
                            <li key={`${archivo.name}-${indice}`}>
                                <span>{archivo.name}</span>
                                <span>{formatoTamano(archivo.size)}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {error && (
                <p className="music-import__error">
                    {error}
                </p>
            )}

            {resultado && (
                <div className="music-import__result">
                    <h3>Resultado de importación</h3>

                    <p>
                        Total: {resultado.total_archivos}
                    </p>

                    <p>
                        Importados: {resultado.importados}
                    </p>

                    <p>
                        Duplicados: {resultado.duplicados}
                    </p>

                    <p>
                        Rechazados: {resultado.rechazados}
                    </p>

                    <ul>
                        {resultado.resultados.map((item, indice) => (
                            <li key={`${item.archivo}-${indice}`}>
                                <strong>{item.archivo}</strong>
                                <span>{item.estado}</span>
                                <p>{item.mensaje}</p>
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            <div className="music-import__actions">
                <button
                    type="button"
                    onClick={() => inputRef.current?.click()}
                    disabled={cargando}
                >
                    Seleccionar archivos
                </button>

                <button
                    type="button"
                    onClick={importar}
                    disabled={cargando || archivos.length === 0}
                >
                    {cargando ? "Importando..." : "Importar"}
                </button>

                <button
                    type="button"
                    onClick={cancelar}
                    disabled={cargando}
                >
                    Cancelar
                </button>
            </div>
        </section>
    );
}

export default MusicImport;