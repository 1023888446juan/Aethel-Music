interface LoadingScreenProps {
    mensaje?: string;
}

function LoadingScreen({ mensaje = "Cargando..." }: LoadingScreenProps) {
    return (
        <div className="loading-screen">
            <p className="loading-screen__message">{mensaje}</p>
        </div>
    );
}

export default LoadingScreen;
