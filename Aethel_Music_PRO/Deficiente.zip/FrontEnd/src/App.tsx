import { BrowserRouter } from "react-router-dom";
import AppRoutes from "./routes/AppRoutes";

function App() {
    return (
        <BrowserRouter>
            <div id="aethel-app">
                <AppRoutes />
            </div>
        </BrowserRouter>
    );
}

export default App;
