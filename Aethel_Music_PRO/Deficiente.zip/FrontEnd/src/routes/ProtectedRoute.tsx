import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import type { ReactNode } from "react";

interface ProtectedRouteProps {
    children?: ReactNode;
}

function ProtectedRoute({ children }: ProtectedRouteProps) {
    const { autenticado, cargando } = useAuth();

    if (cargando) {
        return (
            <div className="auth-loading">
                <p>Verificando sesión...</p>
            </div>
        );
    }

    if (!autenticado) {
        return <Navigate to="/login" replace />;
    }

    return children ? <>{children}</> : <Outlet />;
}

export default ProtectedRoute;
