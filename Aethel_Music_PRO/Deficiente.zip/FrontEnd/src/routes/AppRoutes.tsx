import { Navigate, Route, Routes } from "react-router-dom";

import ProtectedRoute from "./ProtectedRoute";
import MainLayout from "../components/layout/MainLayout";

import LoginPage from "../pages/auth/LoginPage";
import RegisterPage from "../pages/auth/RegisterPage";
import LibraryPage from "../pages/library/LibraryPage";
import PlaylistsPage from "../pages/playlists/PlaylistsPage";

function RoutePlaceholder({ title }: { title: string }) {
    return (
        <section className="route-placeholder">
            <h1>{title}</h1>
            <p>Modulo en construccion.</p>
        </section>
    );
}

function AppRoutes() {
    return (
        <Routes>
            <Route path="/" element={<Navigate to="/login" replace />} />

            <Route path="/login" element={<LoginPage />} />
            <Route path="/registro" element={<RegisterPage />} />

            <Route element={<ProtectedRoute />}>
                <Route element={<MainLayout />}>
                    <Route path="/biblioteca" element={<LibraryPage />} />
                    <Route path="/playlists" element={<RoutePlaceholder title="Playlists" />} />
                    <Route path="/favoritos" element={<RoutePlaceholder title="Favoritos" />} />
                    <Route path="/perfil" element={<RoutePlaceholder title="Perfil" />} />
                    <Route path="/configuracion" element={<RoutePlaceholder title="Configuracion" />} />
                    <Route path="/efectos" element={<RoutePlaceholder title="Efectos" />} />
                </Route>
            </Route>

            <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
    );
}

export default AppRoutes;
