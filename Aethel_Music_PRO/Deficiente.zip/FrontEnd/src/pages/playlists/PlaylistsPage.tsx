
import { useCallback, useEffect, useState } from "react";
import playlistService from "../../services/playlistService";
import type { Playlist } from "../../types/playlist";
import "../../styles/playlists.css";

function PlaylistsPage() {
    const [playlists, setPlaylists] = useState<Playlist[]>([]);
    const [cargando, setCargando] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [nombre, setNombre] = useState("");
    const [editando, setEditando] = useState<number | null>(null);
    const [modalAbierto, setModalAbierto] = useState(false);
    const [guardando, setGuardando] = useState(false);

    const cargarPlaylists = useCallback(async () => {
        setError(null);

        try {
            const datos = await playlistService.obtenerPlaylists();
            setPlaylists(datos);
        } catch (err: any) {
            setError(
                err?.response?.data?.detail ??
                "No fue posible cargar las playlists."
            );
        } finally {
            setCargando(false);
        }
    }, []);

    useEffect(() => {
        cargarPlaylists();
    }, [cargarPlaylists]);

    const abrirCrear = () => {
        setNombre("");
        setEditando(null);
        setError(null);
        setModalAbierto(true);
    };

    const abrirEditar = (playlist: Playlist) => {
        if (playlist.nombre.trim().toLowerCase() === "favoritos") {
            return;
        }

        setNombre(playlist.nombre);
        setEditando(playlist.id_playlist);
        setError(null);
        setModalAbierto(true);
    };

    const cerrarModal = () => {
        if (guardando) return;

        setModalAbierto(false);
        setNombre("");
        setEditando(null);
        setError(null);
    };

    const guardarPlaylist = async (
        e: React.FormEvent<HTMLFormElement>
    ) => {
        e.preventDefault();

        const nombreLimpio = nombre.trim();

        if (!nombreLimpio) {
            setError("El nombre de la playlist es obligatorio.");
            return;
        }

        setGuardando(true);
        setError(null);

        try {
            if (editando !== null) {
                await playlistService.actualizarPlaylist(
                    editando,
                    { nombre: nombreLimpio }
                );
            } else {
                await playlistService.crearPlaylist({
                    nombre: nombreLimpio,
                });
            }

            setModalAbierto(false);
            setNombre("");
            setEditando(null);

            await cargarPlaylists();
        } catch (err: any) {
            setError(
                err?.response?.data?.detail ??
                "No fue posible guardar la playlist."
            );
        } finally {
            setGuardando(false);
        }
    };

    const eliminarPlaylist = async (playlist: Playlist) => {
        if (playlist.nombre.trim().toLowerCase() === "favoritos") {
            setError("Favoritos no puede eliminarse.");
            return;
        }

        const confirmar = window.confirm(
            `¿Deseas eliminar la playlist "${playlist.nombre}"?`
        );

        if (!confirmar) return;

        setError(null);

        try {
            await playlistService.eliminarPlaylist(
                playlist.id_playlist
            );

            setPlaylists((actuales) =>
                actuales.filter(
                    (p) => p.id_playlist !== playlist.id_playlist
                )
            );
        } catch (err: any) {
            setError(
                err?.response?.data?.detail ??
                "No fue posible eliminar la playlist."
            );
        }
    };

    const esFavoritos = (playlist: Playlist) =>
        playlist.nombre.trim().toLowerCase() === "favoritos";

    return (
        <main className="playlists-page">
            <header className="playlists-header">
                <div>
                    <h1>Playlists</h1>
                    <p>Organiza tu música en colecciones.</p>
                </div>

                <button
                    className="playlists-create-button"
                    type="button"
                    onClick={abrirCrear}
                >
                    + Crear playlist
                </button>
            </header>

            {error && !modalAbierto && (
                <div className="playlists-error">
                    {error}
                </div>
            )}

            {cargando ? (
                <div className="playlists-loading">
                    Cargando playlists...
                </div>
            ) : playlists.length === 0 ? (
                <section className="playlists-empty">
                    <h2>No tienes playlists</h2>
                    <p>
                        Crea tu primera playlist y organiza tu música.
                    </p>

                    <button
                        type="button"
                        onClick={abrirCrear}
                    >
                        Crear mi primera playlist
                    </button>
                </section>
            ) : (
                <section className="playlists-grid">
                    {playlists.map((playlist) => (
                        <article
                            className={`playlist-card ${
                                esFavoritos(playlist)
                                    ? "playlist-card--favorites"
                                    : ""
                            }`}
                            key={playlist.id_playlist}
                        >
                            <div className="playlist-card__cover">
                                <span>
                                    {esFavoritos(playlist)
                                        ? "♥"
                                        : "♫"}
                                </span>
                            </div>

                            <div className="playlist-card__info">
                                <h2>{playlist.nombre}</h2>

                                <p>
                                    {esFavoritos(playlist)
                                        ? "Colección de favoritos"
                                        : "Playlist personal"}
                                </p>

                                <span className="playlist-card__date">
                                    {playlist.fecha_creacion
                                        ? new Date(
                                              playlist.fecha_creacion
                                          ).toLocaleDateString()
                                        : ""}
                                </span>
                            </div>

                            <div className="playlist-card__actions">
                                {!esFavoritos(playlist) && (
                                    <>
                                        <button
                                            type="button"
                                            onClick={() =>
                                                abrirEditar(playlist)
                                            }
                                        >
                                            Renombrar
                                        </button>

                                        <button
                                            type="button"
                                            className="playlist-card__delete"
                                            onClick={() =>
                                                eliminarPlaylist(playlist)
                                            }
                                        >
                                            Eliminar
                                        </button>
                                    </>
                                )}

                                {esFavoritos(playlist) && (
                                    <span className="playlist-card__protected">
                                        Playlist protegida
                                    </span>
                                )}
                            </div>
                        </article>
                    ))}
                </section>
            )}

            {modalAbierto && (
                <div
                    className="playlist-modal-overlay"
                    onClick={(e) => {
                        if (e.target === e.currentTarget) {
                            cerrarModal();
                        }
                    }}
                >
                    <section className="playlist-modal">
                        <h2>
                            {editando !== null
                                ? "Renombrar playlist"
                                : "Crear playlist"}
                        </h2>

                        <form onSubmit={guardarPlaylist}>
                            <label htmlFor="playlist-nombre">
                                Nombre
                            </label>

                            <input
                                id="playlist-nombre"
                                type="text"
                                maxLength={150}
                                value={nombre}
                                onChange={(e) =>
                                    setNombre(e.target.value)
                                }
                                placeholder="Nombre de tu playlist"
                                autoFocus
                            />

                            {error && (
                                <div className="playlists-error">
                                    {error}
                                </div>
                            )}

                            <div className="playlist-modal__actions">
                                <button
                                    type="button"
                                    onClick={cerrarModal}
                                    disabled={guardando}
                                >
                                    Cancelar
                                </button>

                                <button
                                    type="submit"
                                    disabled={
                                        guardando ||
                                        nombre.trim().length === 0
                                    }
                                >
                                    {guardando
                                        ? "Guardando..."
                                        : editando !== null
                                        ? "Guardar cambios"
                                        : "Crear"}
                                </button>
                            </div>
                        </form>
                    </section>
                </div>
            )}
        </main>
    );
}

export default PlaylistsPage;
