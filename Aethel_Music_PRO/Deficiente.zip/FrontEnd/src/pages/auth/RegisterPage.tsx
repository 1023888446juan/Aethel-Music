import { useState, type FormEvent } from "react";
import { Link } from "react-router-dom";

function RegisterPage() {
    const [nombre, setNombre] = useState("");
    const [correo, setCorreo] = useState("");
    const [contraseña, setContraseña] = useState("");
    const [confirmarContraseña, setConfirmarContraseña] = useState("");
    const [error, setError] = useState("");

    const manejarRegistro = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError("");

        if (contraseña !== confirmarContraseña) {
            setError("Las contraseñas no coinciden.");
            return;
        }

        setError(
            "El registro aún no está conectado al servicio del backend."
        );
    };

    return (
        <main className="login-page">
            <section className="login-panel">
                <div className="login-panel__branding">
                    <h1>Aethel Music</h1>
                    <p>Tu espacio musical</p>
                </div>

                <div className="login-panel__content">
                    <h2>Crear cuenta</h2>
                    <p className="login-panel__description">
                        Regístrate para acceder a Aethel Music.
                    </p>

                    <form
                        className="login-form"
                        onSubmit={manejarRegistro}
                    >
                        <div className="login-form__field">
                            <label htmlFor="registro-nombre">
                                Nombre
                            </label>

                            <input
                                id="registro-nombre"
                                type="text"
                                autoComplete="name"
                                value={nombre}
                                onChange={(e) => setNombre(e.target.value)}
                                placeholder="Tu nombre"
                                required
                            />
                        </div>

                        <div className="login-form__field">
                            <label htmlFor="registro-correo">
                                Correo electrónico
                            </label>

                            <input
                                id="registro-correo"
                                type="email"
                                autoComplete="email"
                                value={correo}
                                onChange={(e) => setCorreo(e.target.value)}
                                placeholder="correo@ejemplo.com"
                                required
                            />
                        </div>

                        <div className="login-form__field">
                            <label htmlFor="registro-contrasena">
                                Contraseña
                            </label>

                            <input
                                id="registro-contrasena"
                                type="password"
                                autoComplete="new-password"
                                value={contraseña}
                                onChange={(e) => setContraseña(e.target.value)}
                                placeholder="Crear contraseña"
                                required
                            />
                        </div>

                        <div className="login-form__field">
                            <label htmlFor="registro-confirmacion">
                                Confirmar contraseña
                            </label>

                            <input
                                id="registro-confirmacion"
                                type="password"
                                autoComplete="new-password"
                                value={confirmarContraseña}
                                onChange={(e) =>
                                    setConfirmarContraseña(e.target.value)
                                }
                                placeholder="Repetir contraseña"
                                required
                            />
                        </div>

                        {error && (
                            <div className="login-form__error" role="alert">
                                {error}
                            </div>
                        )}

                        <button
                            type="submit"
                            className="login-form__submit"
                        >
                            Crear cuenta
                        </button>
                    </form>

                    <p className="register-login-link">
                        ¿Ya tienes cuenta?{" "}
                        <Link to="/login">Iniciar sesión</Link>
                    </p>
                </div>
            </section>
        </main>
    );
}

export default RegisterPage;
