import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";

import authService from "../../services/authService";
import { useAuth } from "../../context/AuthContext";

function LoginPage() {
    const { establecerSesion } = useAuth();
    const navigate = useNavigate();

    const [correo, setCorreo] = useState("");
    const [contraseña, setContraseña] = useState("");
    const [error, setError] = useState("");
    const [cargando, setCargando] = useState(false);

    const manejarInicioSesion = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError("");
        setCargando(true);

        try {
            const respuesta = await authService.iniciarSesion({
                correo,
                contraseña,
            });

            establecerSesion(
                respuesta.access_token,
                respuesta.usuario
            );

            navigate("/biblioteca", { replace: true });
        } catch {
            setError("No fue posible iniciar sesión. Verifica tus credenciales.");
        } finally {
            setCargando(false);
        }
    };

    return (
        <main className="login-page">
            <section className="login-panel">
                <div className="login-panel__branding">
                    <h1>Aethel Music</h1>
                    <p>Tu espacio musical</p>
                </div>

                <div className="login-panel__content">
                    <h2>Iniciar sesión</h2>
                    <p className="login-panel__description">
                        Ingresa tus credenciales para continuar.
                    </p>

                    <form
                        className="login-form"
                        onSubmit={manejarInicioSesion}
                    >
                        <div className="login-form__field">
                            <label htmlFor="login-correo">
                                Correo electrónico
                            </label>

                            <input
                                id="login-correo"
                                type="email"
                                autoComplete="email"
                                value={correo}
                                onChange={(e) => setCorreo(e.target.value)}
                                placeholder="correo@ejemplo.com"
                                required
                            />
                        </div>

                        <div className="login-form__field">
                            <label htmlFor="login-contrasena">
                                Contraseña
                            </label>

                            <input
                                id="login-contrasena"
                                type="password"
                                autoComplete="current-password"
                                value={contraseña}
                                onChange={(e) => setContraseña(e.target.value)}
                                placeholder="Ingresa tu contraseña"
                                required
                            />
                        </div>

                        {error && (
                            <div className="login-form__error" role="alert">
                                {error}
                            </div>
                        )}

                        <button
                            type="submit"
                            className="login-form__submit"
                            disabled={cargando}
                        >
                            {cargando
                                ? "Ingresando..."
                                : "Iniciar sesión"}
                        </button>
                    </form>
                </div>
            </section>
        </main>
    );
}

export default LoginPage;
