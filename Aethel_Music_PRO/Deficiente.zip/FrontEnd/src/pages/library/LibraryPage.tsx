import { useCallback, useEffect, useState } from "react";
import libraryService from "../../services/libraryService";
import type { Pista } from "../../types/track";
import MusicImport from "../../components/ui/MusicImport";
import "../../styles/library.css";

function LibraryPage() {
    const [pistas, setPistas] = useState<Pista[]>([]);
    const [cargando, setCargando] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [eliminando, setEliminando] = useState<number | null>(null);

    const cargarBiblioteca = useCallback(async () => {
        setCargando(true);
        setError(null);

        try {
            const datos = await libraryService.obtenerPistas();
            setPistas(datos);
        } catch (err: any) {
            setError(
                err?.response?.data?.detail ??
                "No fue posible cargar la biblioteca."
            );
        } finally {
            setCargando(false);
        }
    }, []);

    useEffect(() => {
        cargarBiblioteca();
    }, [cargarBiblioteca]);

    const eliminarPista = async (id: number) => {
        const confirmar = window.confirm(
            "¿Deseas eliminar esta canción de tu biblioteca?"
        );

        if (!confirmar) return;

        setEliminando(id);
        setError(null);

        try {
            await libraryService.eliminarPista(id);

            setPistas((actuales) =>
                actuales.filter((pista) => pista.id_pista !== id)
            );
        } catch (err: any) {
            setError(
                err?.response?.data?.detail ??
                "No fue posible eliminar la canción."
            );
        } finally {
            setEliminando(null);
        }
    };

    const formatearDuracion = (segundos: number) => {
        const minutos = Math.floor(segundos / 60);
        const restante = Math.floor(segundos % 60);

        return `${minutos}:${restante.toString().padStart(2, "0")}`;
    };

    return (
        <main className="library-page">
            <header className="library-page__header">
                <div>
                    <h1>Mi biblioteca</h1>
                    <p>
                        Gestiona y organiza tu colección de música.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={cargarBiblioteca}
                    disabled={cargando}
                >
                    {cargando ? "Actualizando..." : "Actualizar"}
                </button>
            </header>

            <MusicImport onImportComplete={cargarBiblioteca} />

            {error && (
                <div className="library-page__error">
                    {error}
                </div>
            )}

            <section className="library-page__content">
                <div className="library-page__section-header">
                    <h2>Canciones</h2>
                    <span>
                        {pistas.length} canciones
                    </span>
                </div>

                {cargando ? (
                    <p>Cargando biblioteca...</p>
                ) : pistas.length === 0 ? (
                    <div className="library-page__empty">
                        <h3>Tu biblioteca está vacía</h3>
                        <p>
                            Importa archivos de audio para comenzar
                            a construir tu colección.
                        </p>
                    </div>
                ) : (
                    <div className="library-table-container">
                        <table className="library-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Título</th>
                                    <th>Artista</th>
                                    <th>Formato</th>
                                    <th>Duración</th>
                                    <th>Fecha de carga</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>

                            <tbody>
                                {pistas.map((pista, indice) => (
                                    <tr key={pista.id_pista}>
                                        <td>{indice + 1}</td>

                                        <td>
                                            <div className="library-track-title">
                                                {pista.titulo}
                                            </div>
                                        </td>

                                        <td>
                                            {pista.artista || "Desconocido"}
                                        </td>

                                        <td>
                                            {pista.formato.toUpperCase()}
                                        </td>

                                        <td>
                                            {formatearDuracion(
                                                Number(pista.duracion)
                                            )}
                                        </td>

                                        <td>
                                            {pista.fecha_carga
                                                ? new Date(
                                                      pista.fecha_carga
                                                  ).toLocaleDateString()
                                                : "—"}
                                        </td>

                                        <td>
                                            <button
                                                type="button"
                                                className="library-delete-button"
                                                onClick={() =>
                                                    eliminarPista(
                                                        pista.id_pista
                                                    )
                                                }
                                                disabled={
                                                    eliminando ===
                                                    pista.id_pista
                                                }
                                            >
                                                {eliminando ===
                                                pista.id_pista
                                                    ? "Eliminando..."
                                                    : "Eliminar"}
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </section>
        </main>
    );
}

export default LibraryPage;