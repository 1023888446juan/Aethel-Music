export interface Pista {
    id_pista: number;
    uuid_pista: string;
    fk_id_usuario: number;

    titulo: string;
    artista: string | null;

    duracion: number;
    formato: string;

    ruta_archivo: string;
    ruta_portada: string | null;

    fecha_carga: string;
}

export interface ResultadoImportacion {
    estado: "importado" | "duplicado" | "rechazado";
    mensaje: string;
    archivo: string;
    pista?: Pista;
}

export interface RespuestaImportacionMultiple {
    mensaje: string;
    total_archivos: number;
    importados: number;
    duplicados: number;
    rechazados: number;
    resultados: ResultadoImportacion[];
}