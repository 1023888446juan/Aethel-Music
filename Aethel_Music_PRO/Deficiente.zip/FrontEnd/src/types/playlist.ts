
export interface Playlist {
    id_playlist: number;
    fk_id_usuario: number;
    nombre: string;
    fecha_creacion: string;
}

export interface PlaylistCreate {
    nombre: string;
}

export interface PlaylistUpdate {
    nombre: string;
}
