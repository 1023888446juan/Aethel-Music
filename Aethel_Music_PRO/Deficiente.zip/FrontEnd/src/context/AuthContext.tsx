import {
    createContext,
    useContext,
    useEffect,
    useState,
    type ReactNode,
} from "react";

import authService from "../services/authService";

export interface UsuarioAuth {
    id_usuario: number;
    nombre: string;
    correo: string;
    estado_usuario?: boolean;
    ruta_foto_perfil?: string | null;
}

interface AuthContextType {
    usuario: UsuarioAuth | null;
    token: string | null;
    autenticado: boolean;
    cargando: boolean;
    establecerSesion: (token: string, usuario: UsuarioAuth) => void;
    actualizarUsuario: (usuario: UsuarioAuth) => void;
    cerrarSesion: () => void;
    cargarUsuario: () => Promise<void>;
}

interface AuthProviderProps {
    children: ReactNode;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: AuthProviderProps) {
    const [usuario, setUsuario] = useState<UsuarioAuth | null>(null);
    const [token, setToken] = useState<string | null>(() =>
        localStorage.getItem("aethel_token")
    );
    const [cargando, setCargando] = useState<boolean>(true);

    const establecerSesion = (nuevoToken: string, nuevoUsuario: UsuarioAuth) => {
        localStorage.setItem("aethel_token", nuevoToken);
        setToken(nuevoToken);
        setUsuario(nuevoUsuario);
    };

    const actualizarUsuario = (nuevoUsuario: UsuarioAuth) => {
        setUsuario(nuevoUsuario);
    };

    const cerrarSesion = () => {
        localStorage.removeItem("aethel_token");
        setToken(null);
        setUsuario(null);
    };

    const cargarUsuario = async () => {
        const tokenGuardado = localStorage.getItem("aethel_token");

        if (!tokenGuardado) {
            setToken(null);
            setUsuario(null);
            return;
        }

        try {
            const perfil = await authService.obtenerPerfil();

            setUsuario(perfil);
            setToken(tokenGuardado);
        } catch {
            cerrarSesion();
        }
    };

    useEffect(() => {
        const inicializarSesion = async () => {
            try {
                await cargarUsuario();
            } finally {
                setCargando(false);
            }
        };

        inicializarSesion();
    }, []);

    return (
        <AuthContext.Provider
            value={{
                usuario,
                token,
                autenticado: Boolean(token && usuario),
                cargando,
                establecerSesion,
                actualizarUsuario,
                cerrarSesion,
                cargarUsuario,
            }}
        >
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth(): AuthContextType {
    const contexto = useContext(AuthContext);

    if (!contexto) {
        throw new Error(
            "useAuth debe utilizarse dentro de un AuthProvider."
        );
    }

    return contexto;
}
