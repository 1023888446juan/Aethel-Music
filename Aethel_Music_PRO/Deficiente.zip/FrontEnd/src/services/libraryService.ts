import api from "./api";
import type {
    Pista,
    ResultadoImportacion,
    RespuestaImportacionMultiple,
} from "../types/track";

const libraryService = {
    obtenerPistas: async (): Promise<Pista[]> => {
        const respuesta = await api.get<Pista[]>("/pistas/");
        return respuesta.data;
    },

    obtenerPista: async (id_pista: number): Promise<Pista> => {
        const respuesta = await api.get<Pista>(`/pistas/${id_pista}`);
        return respuesta.data;
    },

    obtenerPistaPorUUID: async (uuid_pista: string): Promise<Pista> => {
        const respuesta = await api.get<Pista>(
            `/pistas/uuid/${uuid_pista}`
        );
        return respuesta.data;
    },

    importarPista: async (archivo: File): Promise<ResultadoImportacion> => {
        const datos = new FormData();
        datos.append("archivo", archivo);

        const respuesta = await api.post<ResultadoImportacion>(
            "/pistas/importar",
            datos
        );

        return respuesta.data;
    },

    importarMultiples: async (
        archivos: File[]
    ): Promise<RespuestaImportacionMultiple> => {
        const datos = new FormData();

        archivos.forEach((archivo) => {
            datos.append("archivos", archivo);
        });

        const respuesta = await api.post<RespuestaImportacionMultiple>(
            "/pistas/importar-multiple",
            datos
        );

        return respuesta.data;
    },

    eliminarPista: async (id_pista: number): Promise<{ mensaje: string }> => {
        const respuesta = await api.delete<{ mensaje: string }>(
            `/pistas/${id_pista}`
        );

        return respuesta.data;
    },
};

export default libraryService;