import api from "./api";
import type { UsuarioAuth } from "../context/AuthContext";

export interface LoginCredentials {
    correo: string;
    contraseña: string;
}

export interface LoginResponse {
    access_token: string;
    token_type: string;
    usuario: UsuarioAuth;
}

const authService = {
    iniciarSesion: async (
        credenciales: LoginCredentials
    ): Promise<LoginResponse> => {
        const respuesta = await api.post<LoginResponse>(
            "/auth/login",
            credenciales
        );

        return respuesta.data;
    },

    obtenerPerfil: async (): Promise<UsuarioAuth> => {
        const respuesta = await api.get<UsuarioAuth>("/usuarios/perfil");

        return respuesta.data;
    },
};

export default authService;
