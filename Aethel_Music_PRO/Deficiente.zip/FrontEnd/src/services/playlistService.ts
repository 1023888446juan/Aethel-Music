
import api from "./api";
import type { Playlist, PlaylistCreate, PlaylistUpdate } from "../types/playlist";

const playlistService = {
    obtenerPlaylists: async (): Promise<Playlist[]> => {
        const respuesta = await api.get<Playlist[]>("/playlists/");
        return respuesta.data;
    },

    obtenerPlaylist: async (id_playlist: number): Promise<Playlist> => {
        const respuesta = await api.get<Playlist>(`/playlists/${id_playlist}`);
        return respuesta.data;
    },

    crearPlaylist: async (datos: PlaylistCreate): Promise<Playlist> => {
        const respuesta = await api.post<Playlist>("/playlists/", datos);
        return respuesta.data;
    },

    actualizarPlaylist: async (
        id_playlist: number,
        datos: PlaylistUpdate
    ): Promise<Playlist> => {
        const respuesta = await api.put<Playlist>(
            `/playlists/${id_playlist}`,
            datos
        );
        return respuesta.data;
    },

    eliminarPlaylist: async (id_playlist: number): Promise<{ mensaje: string }> => {
        const respuesta = await api.delete(`/playlists/${id_playlist}`);
        return respuesta.data;
    },
};

export default playlistService;
